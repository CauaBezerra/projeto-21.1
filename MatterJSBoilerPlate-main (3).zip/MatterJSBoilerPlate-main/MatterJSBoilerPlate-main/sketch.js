
const Engine = Matter.Engine;
const World = Matter.World;
const Bodies = Matter.Bodies;
const Body = Matter.Body;

var ball;
var ground,leftside,rightside;

function preload()
{
	
}

function setup() {
	createCanvas(1500, 700);

	engine = Engine.create();
	world = engine.world;

	//Create the Bodies Here.
    ground = new Ground(width/2,670,width,20);
	leftside = new Ground(1100,600,20,120);
	rightside = new Ground(1300,600,20,120);

	var balls_options={
		isStatic:false,
		restitution:0.3,
		friction:0,
		density:1.2
	}
	ball = Matter.Bodies.circle(100,300,50,balls_options);
	World.add(world, ball);

	Engine.run(engine);
  
}


function draw() {
  background(0);
  Engine.update(engine);

  push();
  ellipseMode(CENTER);
  ellipse(ball.position.x,ball.position.y,50,50);
  pop();

  ground.display();
  leftside.display();
  rightside.display();

  keyPressed();
}

function keyPressed(){
   if(keyCode === UP_ARROW){
    Matter.Bodies.applyForce(ball,{x:0,y:0},{x:0.2,y:-0.2});
   }
}
